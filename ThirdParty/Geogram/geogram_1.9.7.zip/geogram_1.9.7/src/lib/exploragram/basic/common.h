
#ifndef EXPLORAGRAM_BASIC_COMMON
#define EXPLORAGRAM_BASIC_COMMON

#include <exploragram/api/defs.h>
#include <geogram/basic/common.h>
#include <geogram/basic/logger.h>

/**
 * \file exploragram/basic/common.h
 * \brief Included by all headers in exploragram.
 */

#endif
