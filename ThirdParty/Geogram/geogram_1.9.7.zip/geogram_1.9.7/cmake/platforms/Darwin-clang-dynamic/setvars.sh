export CC=clang
export CXX=clang++ 
