export AR=x86_64-w64-mingw32-ar
export CC=x86_64-w64-mingw32-gcc
export CXX=x86_64-w64-mingw32-g++
