export AR=ar
export CC=gcc
export CXX=g++
