make clean
rm -fr CMakeCache.txt CMakeFiles Makefile cmake_install.cmake imgui.ini *~
